$(function () {
    $("#login-form").submit(function (e) {
        e.preventDefault();
        var $form = $(this);
        var $login_msg = $('#login-msg');
        $.ajax({
            url: $form.prop('action'),
            type: 'POST',
            data: $form.serialize(),
            dataType: 'json',
            success: function (result) {
                if (result.errcode === 0) {
                    $login_msg.html(alertmsg('alert-success', 'fa-check', '欢迎您使用系统，' + result.data.realname + '！'));
                } else {
                    $login_msg.html(alertmsg('alert-warning', 'fa-warning', result.errmsg));
                }
            },
            beforeSend: function () {
                $('div.alert').children('button').click();
            }
        });
    });
    function alertmsg(type, icon, msg) {
        return '<div class="alert ' + type + ' alert-dismissible">' +
                    '<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>' +
                    '<h4><i class="icon fa ' + icon + '"></i> 警告信息</h4>' + msg +
                '</div>';
    }
});