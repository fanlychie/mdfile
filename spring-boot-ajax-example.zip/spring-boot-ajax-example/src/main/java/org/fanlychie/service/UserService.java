package org.fanlychie.service;

import org.fanlychie.entity.User;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class UserService {

    private List<User> users;

    public Optional<User> findByUsername(String username) {
        return users.stream().filter(u -> u.getUsername().equals(username)).findFirst();
    }

    @PostConstruct
    public void initTestingData() {
        users = new ArrayList<>();
        User u1 = new User();
        u1.setId(1001);
        u1.setRealname("张三");
        u1.setUsername("zs");
        u1.setPassword("123450");
        users.add(u1);
        User u2 = new User();
        u2.setId(1002);
        u2.setRealname("李四");
        u2.setUsername("ls");
        u2.setPassword("123451");
        users.add(u2);
        User u3 = new User();
        u3.setId(1003);
        u3.setRealname("王五");
        u3.setUsername("ww");
        u3.setPassword("123452");
        users.add(u3);
    }

}