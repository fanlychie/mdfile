package org.fanlychie.controller;

import org.fanlychie.dto.JacksonResponse;
import org.fanlychie.dto.UserLoginInputParam;
import org.fanlychie.entity.User;
import org.fanlychie.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.Optional;

@Controller
@RequestMapping("/user")
public class UserController {

    @Autowired
    private UserService userService;

    @GetMapping("/login")
    public String login() {
        return "login";
    }

    @PostMapping("/login")
    public @ResponseBody JacksonResponse login(UserLoginInputParam userLoginInputParam) {
        Optional<User> optional = userService.findByUsername(userLoginInputParam.getUsername());
        if (optional.isPresent()) {
            User user = optional.get();
            if (user.getPassword().equals(userLoginInputParam.getPassword())) {
                return new JacksonResponse(0, null, user);
            }
        }
        return new JacksonResponse(10000, "账户或密码错误", null);
    }

}