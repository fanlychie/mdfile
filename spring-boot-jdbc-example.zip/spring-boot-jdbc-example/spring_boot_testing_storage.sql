DROP TABLE IF EXISTS `user`;

CREATE TABLE `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `name` varchar(32) NOT NULL COMMENT '姓名',
  `sex` char(1) NOT NULL COMMENT '性别',
  `email` varchar(64) NOT NULL COMMENT '邮件',
  `mobile` char(11) NOT NULL COMMENT '电话',
  `birthday` date NOT NULL COMMENT '生日',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COMMENT='用户表';

INSERT INTO `user` VALUES ('1', '张三', '男', 'zhangsan@163.com', '13800138000', '1990-04-27');
INSERT INTO `user` VALUES ('2', '李四', '女', 'lisi@gmail.com', '15989123654', '1995-08-07');
INSERT INTO `user` VALUES ('3', '王五', '男', 'wangwu@126.com', '18889456321', '1993-11-13');
INSERT INTO `user` VALUES ('4', '赵六', '女', 'zhaoliu@yeah.net', '17702012321', '1991-02-14');
