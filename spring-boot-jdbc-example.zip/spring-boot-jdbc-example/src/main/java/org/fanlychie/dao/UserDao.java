package org.fanlychie.dao;

import org.fanlychie.entity.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Created by fanlychie on 2017/4/27.
 */
@Repository
public class UserDao {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    public List<User> selectAll() {
        return jdbcTemplate.query("SELECT * FROM USER", (rs, rn) -> {
            User user = new User();
            user.setId(rs.getInt("id"));
            user.setName(rs.getString("name"));
            user.setSex(rs.getString("sex"));
            user.setEmail(rs.getString("email"));
            user.setMobile(rs.getString("mobile"));
            user.setBirthday(rs.getDate("birthday"));
            return user;
        });
    }

    public void save(User user) {
        jdbcTemplate.update("INSERT INTO USER(NAME, SEX, EMAIL, MOBILE, BIRTHDAY) VALUES (?, ?, ?, ?, ?)",
                user.getName(), user.getSex(), user.getEmail(), user.getMobile(), user.getBirthday());
    }

}