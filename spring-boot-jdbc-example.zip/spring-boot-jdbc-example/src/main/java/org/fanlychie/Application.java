package org.fanlychie;

import org.fanlychie.dao.UserDao;
import org.fanlychie.entity.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.util.Date;

/**
 * Created by fanlychie on 2017/4/27.
 */
@SpringBootApplication
public class Application implements ApplicationRunner {

    @Autowired
    private UserDao userDao;

    @Override
    public void run(ApplicationArguments args) throws Exception {
        System.out.println("===================== 新增 =====================");
        User user = new User();
        user.setName("fanlychie");
        user.setSex("男");
        user.setEmail("fanlychie@yeah.net");
        user.setMobile("15989166266");
        user.setBirthday(new Date());
        userDao.save(user);
        System.out.println("Saved");
        System.out.println("===================== 查询 =====================");
        userDao.selectAll().forEach(System.out::println);
    }

    public static void main(String[] args) {
        SpringApplication.run(Application.class);
    }

}